export const userList = [
    {
        "name":"Dhaval",
        "email":"d@gmail.com",
        "id":1
    },
    {
        "name":"Nakum",
        "email":"n@gmail.com",
        "id":2
    }
]
